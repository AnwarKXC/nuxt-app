const client_manifest = {
  "_ProductCardSkelton.06b5ffee.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProductCardSkelton.06b5ffee.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ]
  },
  "_logo.8bd63d6c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "logo.8bd63d6c.js"
  },
  "_swiper-vue.c9c6819d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.25ac1039.css"
    ],
    "file": "swiper-vue.c9c6819d.js"
  },
  "swiper-vue.25ac1039.css": {
    "file": "swiper-vue.25ac1039.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_up.9078cc5a.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "message.1b619218.png"
    ],
    "file": "up.9078cc5a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "message.1b619218.png": {
    "file": "message.1b619218.png",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png"
  },
  "assets/Untitled.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "Untitled.30d909a7.svg",
    "src": "assets/Untitled.svg"
  },
  "assets/copy.png": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png",
    "file": "copy.dd1b6922.png",
    "src": "assets/copy.png"
  },
  "assets/copy1.png": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png",
    "file": "copy1.d3c4a825.png",
    "src": "assets/copy1.png"
  },
  "assets/faceimg.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "faceimg.9f57cee5.svg",
    "src": "assets/faceimg.svg"
  },
  "assets/group47550.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "group47550.b28cfc60.svg",
    "src": "assets/group47550.svg"
  },
  "assets/instaimg.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "instaimg.c10bbf1b.svg",
    "src": "assets/instaimg.svg"
  },
  "assets/left-alignment.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "left-alignment.7c04bbec.svg",
    "src": "assets/left-alignment.svg"
  },
  "assets/linkdimg.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "linkdimg.e4c31654.svg",
    "src": "assets/linkdimg.svg"
  },
  "assets/message.png": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png",
    "file": "message.1b619218.png",
    "src": "assets/message.png"
  },
  "assets/paylogo.png": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png",
    "file": "paylogo.8e25392b.png",
    "src": "assets/paylogo.png"
  },
  "assets/twitterimg.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "twitterimg.585fdad1.svg",
    "src": "assets/twitterimg.svg"
  },
  "assets/whatsimg.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "whatsimg.7a0e75f6.svg",
    "src": "assets/whatsimg.svg"
  },
  "components/AboutSection.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "dynamicImports": [
      "components/FetchAbout.vue"
    ],
    "file": "AboutSection.2d6ada58.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.8bd63d6c.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "components/AboutSection.vue"
  },
  "components/BlogSection.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "dynamicImports": [
      "components/ProductList.vue"
    ],
    "file": "BlogSection.7f24673e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ProductCardSkelton.06b5ffee.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "components/BlogSection.vue"
  },
  "components/ContactUs.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "dynamicImports": [
      "components/contactDetails.vue",
      "components/FormSection.vue"
    ],
    "file": "ContactUs.d563c29c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "components/ContactUs.vue"
  },
  "components/FetchAbout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "FetchAbout.cfc23af6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "components/FetchAbout.vue"
  },
  "components/FormSection.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "FormSection.d76b45c5.js",
    "imports": [
      "_swiper-vue.c9c6819d.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "components/FormSection.vue"
  },
  "components/HeroSection.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "HeroSection.05e205b1.css",
    "src": "components/HeroSection.css"
  },
  "components/HeroSection.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "dynamicImports": [
      "components/SwippingTop.vue",
      "components/sliderImage.vue"
    ],
    "file": "HeroSection.10608861.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "components/HeroSection.vue"
  },
  "HeroSection.05e205b1.css": {
    "file": "HeroSection.05e205b1.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/LastArticle.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "LastArticle.62ebadae.js",
    "imports": [
      "node_modules/@nuxt/image/dist/runtime/components/nuxt-img.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "components/LastArticle.vue"
  },
  "components/NumbersSection.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "NumbersSection.28f87fc8.js",
    "imports": [
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "components/NumbersSection.vue"
  },
  "components/PartnersSection.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "PartnersSection.61c45571.css",
    "src": "components/PartnersSection.css"
  },
  "components/PartnersSection.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "dynamicImports": [
      "node_modules/@nuxt/image/dist/runtime/components/nuxt-img.mjs"
    ],
    "file": "PartnersSection.e241dea1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "components/PartnersSection.vue"
  },
  "PartnersSection.61c45571.css": {
    "file": "PartnersSection.61c45571.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/PopluarService.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "PopluarService.09748ec3.css",
    "src": "components/PopluarService.css"
  },
  "components/PopluarService.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "dynamicImports": [
      "node_modules/@nuxt/image/dist/runtime/components/nuxt-img.mjs"
    ],
    "file": "PopluarService.4d9c0616.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "components/PopluarService.vue"
  },
  "PopluarService.09748ec3.css": {
    "file": "PopluarService.09748ec3.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/ProductCard.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "dynamicImports": [
      "node_modules/@nuxt/image/dist/runtime/components/nuxt-img.mjs"
    ],
    "file": "ProductCard.68c1fd69.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "components/ProductCard.vue"
  },
  "components/ProductList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "dynamicImports": [
      "components/ProductCard.vue"
    ],
    "file": "ProductList.2c0e1e80.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "components/ProductList.vue"
  },
  "components/SwippingTop.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "SwippingTop.ac295b0a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_up.9078cc5a.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "components/SwippingTop.vue"
  },
  "components/contactDetails.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contactDetails.9c0055e7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_up.9078cc5a.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "components/contactDetails.vue"
  },
  "components/sliderImage.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "sliderImage.b609fd7f.css",
    "src": "components/sliderImage.css"
  },
  "components/sliderImage.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "dynamicImports": [
      "node_modules/@nuxt/image/dist/runtime/components/nuxt-img.mjs"
    ],
    "file": "sliderImage.6344d3c2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "components/sliderImage.vue"
  },
  "sliderImage.b609fd7f.css": {
    "file": "sliderImage.b609fd7f.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "i18n.config.js?hash=c231e734&config=1": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "i18n.config.3bfbe7fc.js",
    "isDynamicEntry": true,
    "src": "i18n.config.js?hash=c231e734&config=1"
  },
  "middleware/resizeImages.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "resizeImages.c07fa741.js",
    "isDynamicEntry": true,
    "src": "middleware/resizeImages.js"
  },
  "node_modules/@nuxt/image/dist/runtime/components/nuxt-img.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-img.af498f64.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/image/dist/runtime/components/nuxt-img.mjs"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-404.7fc72018.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-404.63e88937.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.7fc72018.css": {
    "file": "error-404.7fc72018.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-500.c5df6088.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-500.ede8cef0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.c5df6088.css": {
    "file": "error-500.c5df6088.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "entry.f468260a.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "copy.dd1b6922.png",
      "copy1.d3c4a825.png",
      "group47550.b28cfc60.svg",
      "left-alignment.7c04bbec.svg",
      "Untitled.30d909a7.svg",
      "paylogo.8e25392b.png"
    ],
    "css": [
      "entry.f468260a.css"
    ],
    "dynamicImports": [
      "middleware/resizeImages.js",
      "node_modules/workbox-window/build/workbox-window.prod.es5.mjs",
      "i18n.config.js?hash=c231e734&config=1",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.973bd0da.js",
    "imports": [
      "_swiper-vue.c9c6819d.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.f468260a.css": {
    "file": "entry.f468260a.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "copy.dd1b6922.png": {
    "file": "copy.dd1b6922.png",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png"
  },
  "copy1.d3c4a825.png": {
    "file": "copy1.d3c4a825.png",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png"
  },
  "group47550.b28cfc60.svg": {
    "file": "group47550.b28cfc60.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "left-alignment.7c04bbec.svg": {
    "file": "left-alignment.7c04bbec.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "Untitled.30d909a7.svg": {
    "file": "Untitled.30d909a7.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "paylogo.8e25392b.png": {
    "file": "paylogo.8e25392b.png",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png"
  },
  "node_modules/workbox-window/build/workbox-window.prod.es5.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "workbox-window.prod.es5.a7b12eab.js",
    "isDynamicEntry": true,
    "src": "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
  },
  "pages/Contact.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "dynamicImports": [
      "components/contactDetails.vue",
      "components/FormSection.vue"
    ],
    "file": "Contact.d65d0e51.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Contact.vue"
  },
  "pages/Privacy.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Privacy.b7f6b463.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Privacy.vue"
  },
  "pages/Return.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Return.8420db3b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Return.vue"
  },
  "pages/Terms.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Terms.b5ccc9c6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Terms.vue"
  },
  "pages/about/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.47540d09.js",
    "imports": [
      "components/FetchAbout.vue",
      "components/PartnersSection.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.8bd63d6c.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/about/index.vue"
  },
  "pages/blog/[id].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_id_.2c74fcf1.css",
    "src": "pages/blog/[id].css"
  },
  "pages/blog/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "faceimg.9f57cee5.svg",
      "instaimg.c10bbf1b.svg",
      "whatsimg.7a0e75f6.svg",
      "twitterimg.585fdad1.svg",
      "linkdimg.e4c31654.svg"
    ],
    "css": [],
    "dynamicImports": [
      "components/LastArticle.vue"
    ],
    "file": "_id_.2a4d1bc9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/blog/[id].vue"
  },
  "_id_.2c74fcf1.css": {
    "file": "_id_.2c74fcf1.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "faceimg.9f57cee5.svg": {
    "file": "faceimg.9f57cee5.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "instaimg.c10bbf1b.svg": {
    "file": "instaimg.c10bbf1b.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "whatsimg.7a0e75f6.svg": {
    "file": "whatsimg.7a0e75f6.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "twitterimg.585fdad1.svg": {
    "file": "twitterimg.585fdad1.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "linkdimg.e4c31654.svg": {
    "file": "linkdimg.e4c31654.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "pages/blog/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.3d9b5ff2.css",
    "src": "pages/blog/index.css"
  },
  "pages/blog/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "dynamicImports": [
      "components/SwippingTop.vue",
      "components/ProductList.vue"
    ],
    "file": "index.560362fc.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ProductCardSkelton.06b5ffee.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/blog/index.vue"
  },
  "index.3d9b5ff2.css": {
    "file": "index.3d9b5ff2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "dynamicImports": [
      "components/HeroSection.vue",
      "components/AboutSection.vue",
      "components/NumbersSection.vue",
      "components/PartnersSection.vue",
      "components/PopluarService.vue",
      "components/BlogSection.vue",
      "components/ContactUs.vue"
    ],
    "file": "index.9165bf99.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c9c6819d.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.25ac1039.css",
    "src": "swiper-vue.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
