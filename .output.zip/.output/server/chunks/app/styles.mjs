const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.48ac1cc3.mjs').then(interopDefault),
  "pages/blog/[id].vue": () => import('./_nuxt/_id_-styles.b3b94d87.mjs').then(interopDefault),
  "pages/blog/index.vue": () => import('./_nuxt/index-styles.e687011a.mjs').then(interopDefault),
  "components/PartnersSection.vue": () => import('./_nuxt/PartnersSection-styles.0f521b5a.mjs').then(interopDefault),
  "components/HeroSection.vue": () => import('./_nuxt/HeroSection-styles.cd9ee588.mjs').then(interopDefault),
  "components/PopluarService.vue": () => import('./_nuxt/PopluarService-styles.ea24aec2.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.cf4b3e80.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.1e0dde27.mjs').then(interopDefault),
  "components/sliderImage.vue": () => import('./_nuxt/sliderImage-styles.bd086418.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
