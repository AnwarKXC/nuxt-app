import { ref, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import CountUp from 'vue-countup-v3';

const duration = 12;
const _sfc_main = {
  __name: "NumbersSection",
  __ssrInlineRender: true,
  setup(__props) {
    const isVisible = ref(false);
    const sectionToObserve = ref(null);
    ref({
      threshold: 1
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({
        ref_key: "sectionToObserve",
        ref: sectionToObserve,
        class: "container text-center font-arabic text-[20px] leading-[35px] py-10 flex justify-center"
      }, _attrs))}><div class="max-w-[938px] text-center flex justify-center flex-col"><h1 class="titleNum items-center">${ssrInterpolate(_ctx.$t("\u0631\u064A\u0641\u0627\u064A\u0646 \u0641\u064A \u0627\u0631\u0642\u0627\u0645"))}</h1><div class="flex justify-evenly items-center flex-wrap gap-8"><div class="text-20px"><h1 class="title-num">`);
      if (unref(isVisible)) {
        _push(ssrRenderComponent(unref(CountUp), {
          "end-val": 26,
          duration
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`+</h1><p>${ssrInterpolate(_ctx.$t("\u0645\u0639\u0645\u0644 \u062A\u062D\u0627\u0644\u064A\u0644"))}</p></div><div class="target"><h1 class="title-num">`);
      if (unref(isVisible)) {
        _push(ssrRenderComponent(unref(CountUp), {
          "end-val": 17,
          duration
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(` +</h1><p>${ssrInterpolate(_ctx.$t("\u0645\u0633\u062A\u0634\u0641\u064A"))}</p></div><div><h1 class="title-num">`);
      if (unref(isVisible)) {
        _push(ssrRenderComponent(unref(CountUp), {
          "end-val": 33,
          duration
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`+</h1><p>${ssrInterpolate(_ctx.$t("\u0645\u0639\u0645\u0644 \u0623\u0634\u0639\u0629"))}</p></div><div><h1 class="title-num">`);
      if (unref(isVisible)) {
        _push(ssrRenderComponent(unref(CountUp), {
          "end-val": 20,
          duration
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`+</h1><p>${ssrInterpolate(_ctx.$t("\u0639\u064A\u0627\u062F\u0629"))}</p></div></div></div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/NumbersSection.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=NumbersSection-5901aacf.mjs.map
