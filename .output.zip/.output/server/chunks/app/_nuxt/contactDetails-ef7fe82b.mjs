import { ref, unref, useSSRContext } from 'vue';
import { b as useI18n } from '../server.mjs';
import { ssrRenderAttr, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import { _ as _imports_3, a as _imports_4 } from './up-d5a59b14.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _imports_0 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAAyCAYAAAAJHRh4AAAABHNCSVQICAgIfAhkiAAABJhJREFUaEPtms9PE1EQx9/bSikxkUr8sYWDNV5MjLH8SvQE/gVKjEdDuXgxkcLJxAPlrrE10SuQePAmHD1Zr8qPkmjizRIDrcEECGqgsPucWXZhd7s/3mtLQsxr0gS2b2fn852Z95rOUNLAS1X7Billo2AiBe8kvEuUkgKlSn519XOxAdNNu5XWY8kEm4B7BwPuLzBGJyuV+UI9z2jWPUKAqppKKkpkgjGSFnDg2EFVtX8gFttbLpWKm26/uACTyVR8Z0cZpZRmwEDcbkRvU99ot55FSPzqtvLj/eap+acXQYBhDwGaBor+7O5G8BnoD5aG9cISGVtbW5i1LoQCqmrvMNyUdRnC++cY0zLVe0unFUIe4wUw9nX9FX1pRjp7HKCJRC/WPPrjENouKPg7DZAjpk/eyRZQZ8tQWxmrtjoesWtuQMtiM0FNf6Y8hMbHLQNUEgRtP6JhY+XyYq4mgn51Bga2dJ0B2OK0XZIgwGaAdnX1p3RdfwG2Bl2hWGGMZS1/zLQtwJob5rpSubxw2QGoqj0TXnUG1yaj0f2cVxHzANYDGiQ0gmF03LlnQuLxdAk/UxSl2wA0P3jnoZJRZ5VKseSdyISIAHKClpiibFNdv+7xzHxrq5b1Etpam0j0QBTpwMH/bMwAhML94IJz1JkfHF6vB5AT1PZY9pExPR0ktLW4s7MPNjeGZzTBzKOQlmn4A4vXeEGtzcAOlA6Csn/WCGANKKFDhLEzNvuQQTQn8mWhBhCih2fGHdPoHBTmXV64RiPofs65hyxB/nx7rlQ3o/r5m19+vaZZEV9wrRfgBlw3zhRQ67aIWscC2GKcceAMKTcLkFkqQfRCD363os1IUcumEUEJGJy0XikqIxikmUxRgW1Q1iCHWLIGOURyLJE1KKCYrEEOsWQNcogka1BUJPldVEAxWYMCYhlL5TkooJg8BznEkjXIIZI8B0VFkueggGKyBgXEOpHnIPyQjU0Z7CEe/HQPF/6rX9WAZwnYcCgCfshmIw0BYleq2pIc11vaHxDtb5Tq2k+2vZKvVBZmRDMB1zd60Hd29k7Z5wegE3W2LkBbzz7rA7IJ6uViMT0f1Opy31svIPYSKY1gk9TeV8nDL/UZByA2DMPmW8yePea5b4/c5rgQqChgwHDEMsAZaQqARw1DaJ0N2ScU7Ar798ixd0emoZ8KEw46GDUmMYwOqyioCKDfcAS2/6JRLWNlDkbwcNcBh0qQt932tDLDj/3DQZfTK2As4yWI2XPE9BUC5QHkHY6wfIUGqJG/323OF6F+jDkT2GYxzI5+IQ4jwCe5tbV5v/o7NCUKGgQoOhxxCIh/2E9/n03DuOwOf9BaZ3obXeTQiPoB1jMc4QDEf9ytbLuDCAYDdrmwDSgMOCyiSurJ2+qV++OGHWiARmf7IJsI7o5Jl+3Q4YgaQLxwMG2hpCFWkLYUdkAd37M8zf8wOJ6IQod5i3Rc22BtF7aV9U9dZO93h8su93CEJ6CIk81YGxBRh3m/ISQeH4Rb1jxGRdf4gVobmt8QEs9zTgSg5SiObWmalgKwOGNKMRbbL4p8E/IC/gfuPYmA+vCuYAAAAABJRU5ErkJggg==";
const _imports_1 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADcAAAA2CAYAAABjhwHjAAAABHNCSVQICAgIfAhkiAAABzdJREFUaEPdWj1sFEcUntnDZ8VNSByiswnK0dByYChCw5G0RDENLXYTKaYAky5CwiiEDmEKHCkN0LqJEbQodoOLGHJuaXKIYFshTkgTMLZ3+N7u7Hp2d3Z3ZnexpayEzO3O3zfve99783Y5K3ntPSv61x32ieuyfYKxfVywPoex+T+n+MOSQ3vdG41Wk/Nd5xgTLX883hFi48bKSqebNz7Pa6B7Pvi16Hvdww46gh1jnB1ItBHsj7+m+PdFxlb7NBqHL3HOz+Pe7vhYnLPbrrt5OQukFTgC9aaHfY6JvsC/vrTFw3rzL6b47aLgms3W7rW12i30H84Z4yVAji4tPZrRtTMGt2dMtFzOTqNDv8ZST3DvCei4usHYs7+n+LOSwH5Bf0lDGknMwYKTrstfOo4YEYKdiY7PJ5eXF8YT1s1bBFlrrYedAShlMjAfQFzGHvSus/mln/h/eeOYPJcWiwADqMtLSwsTav+9e4+2XNclZhwM7hNNYcFRtV2m5QjYeg+7QEIRdMKuvaoxNl2VYATj6oAJIUZXVh5r6U3t37ypTapWjANMBffhmNjncHYh4luC3a9vsAdVWaooMNU6g4NDt2M0vbG8/IhEiNiVvKRw/KACgzLeqdpawcwDA0O/qT6WZTHtemMAYcFTJDIJcHEqEg1By2tlRCLL3wBsEs8Rx/zLFpiyQaSYX8nfXVhvfwJc/5gYA/LQUV3BrpgCo4D+irED70E5n9/kq1mg6JkUBrJaAG18efkxgbW+pA92YYz3/U3iJyLgSO4FZ98EI5tQkXyzxtlnUM5WGCYEe4Igfi1vhaq/YEPvgEojeX1MWUAqG4KTkn9RWeB9LPBe2mCSvidBWQro0csQHCj5Dzp62Udv7+YH3W7nZRlw2KxhWO5nfwzExmCwj8bEl5CXk/SbYljPOruSporSWmfUEOFTgb1CIO/UObtnQkuAwxD+QkDHdhlg1LfRONLmXFCc3AIXV8csOsoQcVFdCEAtAtRDpFwdmwVugWMdCMAhm766tlpwH4+JY0itvJSGrPbiJv9O11mnpGUCOsB1Mc+nvtU395tk+lkboKUlKPltkN2DJ9OrN/kD3SB7zorTgY9VESIALpTvoiFAXWc0oItxTvK9xtjVoFF9nY3rfC1ORxMlzaPZwMBhZBL8useYatQyFCjHcQ7xiPxnqFzMaourU3wqb/F5z2Nxzgu8eX3SnsfGeoqxmlxVSYbcMU3+Ae4qKOkdd3Be+9FWPNIWpfod7fbz579aiVIwrprpBCzgakaSRjWVkuRrsJqXmFZxgZqz2K7jvqjwEysrC/htd8kTxe/o5cXMMLdUxSQt1VKpW/aUHV92FeCi+elWzPR8Dkp5GpN2EAKmdXvmiY5gI9iR/jqSaJMAbbL3csdJBLyrSDjwC0g1spocY8v6xmUGk8XatlHVEn09EbAfY4jSLVlriWY6OwxuiHbcA6QrJ+QBjWYkScvvGDgE3FsQpxEpAP/W65tNm8RZUpqOS3JzkqeKHQGHeiT8l1PpLvAU63McRCSkI7RAuznbDk5zQLU+EcR8NTWEbCs46SO040EF+SnOcS0bOsb9LMtXtw1cnIpEJc6dtk1GEg/WeefAwuBoItMdV8UjEBBbYNQPfkYH0bapCBmDI18Rwj0HhaPKs1p9nsVxZbZWq91VrUDgX792zoE2pIhq/FpEDjliYzECE98gk1TNCJx82zKRF3fk81n519vh6CXmenvdYVOLB33jwEBHI3XNBKcrcfsTijn/r5/w5l3kX7DuRJGy3eDgkQn0vRTMYXPuSwWnfynB7iDYng92XtYKyUJUdaK/XslAuRZBy5l6fWPS1lo0hkaErMp/WnC2LyUCML6f7ZL+uNEtUxMpC8zjVZxSRYHlUdPmeTKDYYuIh21b60fA/Z+AJSyXlNv092M2ljBtW5XFQvEJ/hNXpSpKbaagdOKBe4WoqM7p0VKeZun4IGsQyVe1Ngu1bTswcATlPaHWZUoDC2kZtVo1dXtTgMkAXd5iEVqqRZqgcmS6uDLtNDlnJI6WGTu03HaDk6pMR592uMsVVJzjm+H5XOzwN4NCzamyu5bWX3Omq6SUrptPFRRteaxKkPoE3CwJLrKOrTer0S8CusgIDtlmBGkL0H3uRMk0vggaLlJhNgUagpMLoDp9kPxW+UKQikHNrUUVO/qYgoqoZfAjWZ9IfnJkOoGMnQQqFA1PwTSfO5mOadsukThrsvHEN1VZk8hj0PWgJqmo4TunoVYt4zfjH77geQelgdGs0kCjcfQ4XrajrC1G0D7yfSQdMNVzoK0FirZPPaxqvqmiOWaQc8Iva7P+hG7TcVgbVqJafeKDT9y7i5cb58uc64oC81wgqzO9QMdz+nDM+yrH/BJzQjgT71IJTdaSWyDyVdTBi/nceslTsiwoOJv25arJgqpskwsumIzUz3FqKCFwKvG1lUWAqu7MTlEvazPeAg5VKP7e/WLuAAAAAElFTkSuQmCC";
const _imports_2 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADkAAAAxCAYAAABgSwHoAAAABHNCSVQICAgIfAhkiAAABOZJREFUaEPtWj1zE1cUfXdt4cQNBoeMLMPENKb0FxShiZi0mUkooI1oMhO7CEN+AOYHAKawMpMmdusm5gcwyI1dAI5chiaaMZY1BCVOAzG29ubc1b717uprtZGyq4xeJe2+3XfPPefe9/bdR6pFSyanJwxjcIpZpZXiabs7fkfS8hj1QCnKMzN+VzZKpXyhlSXUqEMyeTlNxN/h/letXhLx/XVmelQqPc81sqMG5MTE9Mjh4cBPPQDOj2l9aKhyq1DIg2lv84AcH78ybZqmANSy1L138CNHpHKmSQfNvNZNVsW+SoVHDEOlIVex8UvfeAXDMK7v7T0TWTvNAWkz+NQLkDeYjcWoQLVyWDVfDCwiX3zt6lsAozNuRh2QY2NzP/sk+mh//8XtVgPF4X4qNSd5YwVgT9v25GH7jLbNAmknGWFRt54BqA22Q+0X/R9yvlUqba/IfwskWFw/0Tdv7O9vp+PAULs2jI3NQnn00H6uADYvWiBF10QDv514gK7FNQaDgIZ0D7RskSivF4sv1kn0jIsSj9J2gN6fWYO8OzZ9UqnLSER81zbICjuCVJdwQSZ9aT0Xi37v+vKLlYAAcjYH1X5mademNza0hDQExLF+FCDJAxLLo56ORw3MTRwWB8KkF3VI58XqMTdIIS40yI/n+WqC1K97y1TuJsLUNzz8d0JNfXCkdoo/0tsgY3UE5OgCf44J9qYMaLBafZ2lzSCDt9vn7DxfQJ74FmONKlYv32TpfpB3dATkuXnOMKlP9YCI8s3yMq0GMSBoH1GKSeoG+g/LM5jm3pWzFGiZ2RGQIqH3g+p7rJfOa6Ph7d3EkXoQVFLNwNY4EQDhyPt/ZGk3iJM6AlIP5DcG19+arB4ENcZvsDjvKKHuANAF5x6rV0Oksu3EfkdBiiG2rNyfOqHiVOLPIHVHy9Oat1ltJY7VWrvq6DhIMeajBZ5EzMwjSXwYJk7rOQpsriHOnwSRp79PV0DKIOMLPHoIoP44PaXUD42kJvI8TKgbiOerjnMQf3BW9s0yvQwDUJ7pGkh5uRVTg+qmO/NamRHZF0C2hpQq85F69z6hzkvc4doXbnmiY9vxV88RXQWpB3TPo0HZCBt/kYF0yTcD+U42Awo2y2Bw7fcseTafgjonUpB6cElKAHEJ/ycRa6OYYoZlTsXvXbD3qhurpf9Erv+GhU482wcpH5id8GTU7+gz2Wcyag22MX5frn25tiGXqLvWk2sBRn0ihsn2nb+2F7XBYcavA/Jkc/n/s+869yecMyIOQq3yjNRCpK5nfdkT0b1i8fliGO/F5Rl3CQ/r479Q8BmRHXR3uesxkk/cD0I09WcyOZsBWXIkAK1ahqTa4mXlYpBjI3Fhzm8HKgJSiLUqc1qZugjrJB9QvAqKM3EF0cwuf8WcuUqYXU53U9yb1S37YIcUk62Eg+aEnvtghMMmOhxgOrnWK9NJvZMr7pnCASmxyWzmXCcosDXPON6yfS/O0rUlKpVyzWDNLOH5fvRmJgcaavCMavRArlR6thEHwNVDS+YU8ofURjzl/3o5peYjWTxjGIzzas6ZGD+uXMRABZTDmtuWRvN83Z0AW+OL8EqmCdiIsXqGf4wYXGp0aqXpdkcVrIHphNK2LKw1btRNVjJyFJTIwFm/45VW83rbezoi52hBHhdagfLb9w/BGLYn40CKSgAAAABJRU5ErkJggg==";
const _sfc_main = {
  __name: "contactDetails",
  __ssrInlineRender: true,
  setup(__props) {
    const addressAR = ref([]);
    const addressEN = ref([]);
    const emails = ref([]);
    const phoneNumbers = ref([]);
    useI18n();
    let lang = ref("");
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="flex flex-col items-center"><img class="contact"${ssrRenderAttr("src", _imports_0)} alt="social icon"><h2 class="title-contact">${ssrInterpolate(_ctx.$t("\u0633\u0639\u062F\u0627\u0621 \u0628\u0632\u064A\u0627\u0631\u062A\u0643"))}</h2>`);
      if (unref(lang) == "ar") {
        _push(`<!--[-->`);
        ssrRenderList(unref(addressAR), (item) => {
          _push(`<p class="form-text"><p>${ssrInterpolate(item)}</p></p>`);
        });
        _push(`<!--]-->`);
      } else {
        _push(`<!---->`);
      }
      if (unref(lang) == "en") {
        _push(`<!--[-->`);
        ssrRenderList(unref(addressEN), (item) => {
          _push(`<p class="form-text"><p>${ssrInterpolate(item)}</p></p>`);
        });
        _push(`<!--]-->`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="flex flex-col items-center"><img class="contact"${ssrRenderAttr("src", _imports_1)} alt=""><h2 class="title-contact">${ssrInterpolate(_ctx.$t("\u0625\u062A\u0635\u0644 \u0628\u0646\u0627"))}</h2><!--[-->`);
      ssrRenderList(unref(phoneNumbers), (item) => {
        _push(`<p class="form-text"><a${ssrRenderAttr("href", "tel:" + item)}>${ssrInterpolate(item)}</a></p>`);
      });
      _push(`<!--]--></div><div class="flex flex-col items-center"><img class="contact"${ssrRenderAttr("src", _imports_2)} alt="social icon"><h2 class="title-contact">${ssrInterpolate(_ctx.$t("\u0633\u0639\u062F\u0627\u0621 \u0628\u0632\u064A\u0627\u0631\u062A\u0643"))}</h2><!--[-->`);
      ssrRenderList(unref(emails), (item) => {
        _push(`<p class="form-text"><a${ssrRenderAttr("href", "mailto:" + item)}>${ssrInterpolate(item)}</a></p>`);
      });
      _push(`<!--]--></div><div class="hidden flex-col absolute bottom-4"><img width="105"${ssrRenderAttr("src", _imports_3)} alt="social icon"><div class="w-[105] flex justify-center"><img width="28"${ssrRenderAttr("src", _imports_4)} alt="social icon"></div></div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/contactDetails.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=contactDetails-ef7fe82b.mjs.map
