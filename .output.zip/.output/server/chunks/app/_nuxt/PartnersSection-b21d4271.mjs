import { Swiper, SwiperSlide } from 'swiper/vue';
import { ref, watchEffect, mergeProps, unref, withCtx, createVNode, openBlock, createBlock, Fragment, renderList, useSSRContext, defineAsyncComponent } from 'vue';
import { _ as _export_sfc, b as useI18n } from '../server.mjs';
import { Autoplay, Navigation } from 'swiper/modules';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderList, ssrRenderSlot } from 'vue/server-renderer';
import axios from 'axios';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';

const __nuxt_component_2_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./nuxt-img-fa989413.mjs').then((m) => m.default || m));
const _sfc_main = {
  __name: "PartnersSection",
  __ssrInlineRender: true,
  setup(__props) {
    const { locale } = useI18n();
    let sliderData = ref([]);
    let isLoading = ref(true);
    const getData = async () => {
      try {
        const response = await axios.get("https://dev.refine-care.com/api/v1/partners", {
          headers: {
            lang: locale.value
          }
        });
        const data = response.data.records;
        sliderData.value = data;
        isLoading.value = false;
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    watchEffect(() => {
      getData();
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Swiper = Swiper;
      const _component_swiper_slide = SwiperSlide;
      const _component_LazyNuxtImg = __nuxt_component_2_lazy;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "w-screen bg-[#ECF5FB] flex justify-center items-center font-arabic py-5" }, _attrs))} data-v-f9cdd237><div class="container text-center font-arabic text-[20px] leading-[35px]" data-v-f9cdd237><div class="max-w-[938px] mx-auto container" data-v-f9cdd237><h1 class="title" data-v-f9cdd237>${ssrInterpolate(_ctx.$t("\u0634\u0631\u0643\u0627\u0621\u0646\u0627"))}</h1></div><div data-v-f9cdd237><div class="flex items-center justify-between gap-4 pt-12 px-10 md:px-14 relative" data-v-f9cdd237><div class="swiper-button-next md:px-4 pt-12" data-v-f9cdd237></div>`);
      _push(ssrRenderComponent(_component_Swiper, {
        breakpoints: {
          "200": {
            slidesPerView: 1,
            spaceBetween: 50
          },
          "350": {
            slidesPerView: 2,
            spaceBetween: 10
          },
          "460": {
            slidesPerView: 2.5,
            spaceBetween: 40
          },
          "640": {
            slidesPerView: 3,
            spaceBetween: 20
          },
          "768": {
            slidesPerView: 3.5,
            spaceBetween: 40
          },
          "1024": {
            slidesPerView: 4.5,
            spaceBetween: 35
          },
          "1244": {
            slidesPerView: 6.35,
            spaceBetween: 35
          }
        },
        modules: ["SwiperAutoplay" in _ctx ? _ctx.SwiperAutoplay : unref(Autoplay), "SwiperNavigation" in _ctx ? _ctx.SwiperNavigation : unref(Navigation)],
        navigation: {
          prevEl: ".swiper-button-next",
          nextEl: ".swiper-button-prev"
        },
        autoplay: {
          delay: 2e3,
          disableOnInteraction: false
        },
        "grab-cursor": true
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (unref(isLoading)) {
              _push2(`<!--[-->`);
              _push2(ssrRenderComponent(_component_swiper_slide, { class: "animate-pulse mx-4" }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_swiper_slide, { class: "animate-pulse mx-4" }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_swiper_slide, { class: "animate-pulse mx-4" }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_swiper_slide, { class: "animate-pulse mx-4" }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_swiper_slide, { class: "animate-pulse mx-4" }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_swiper_slide, { class: "animate-pulse mx-4" }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_swiper_slide, { class: "animate-pulse mx-4" }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_swiper_slide, { class: "animate-pulse mx-4" }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_swiper_slide, { class: "animate-pulse mx-4" }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_swiper_slide, { class: "animate-pulse mx-4" }, null, _parent2, _scopeId));
              _push2(`<!--]-->`);
            } else {
              _push2(`<!--[-->`);
              ssrRenderList(unref(sliderData), (item) => {
                _push2(ssrRenderComponent(_component_swiper_slide, null, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(_component_LazyNuxtImg, {
                        format: "webp",
                        src: item.main_image,
                        quality: "50",
                        alt: item.name
                      }, null, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(_component_LazyNuxtImg, {
                          format: "webp",
                          src: item.main_image,
                          quality: "50",
                          alt: item.name
                        }, null, 8, ["src", "alt"])
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]-->`);
            }
          } else {
            return [
              unref(isLoading) ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                createVNode(_component_swiper_slide, { class: "animate-pulse mx-4" }),
                createVNode(_component_swiper_slide, { class: "animate-pulse mx-4" }),
                createVNode(_component_swiper_slide, { class: "animate-pulse mx-4" }),
                createVNode(_component_swiper_slide, { class: "animate-pulse mx-4" }),
                createVNode(_component_swiper_slide, { class: "animate-pulse mx-4" }),
                createVNode(_component_swiper_slide, { class: "animate-pulse mx-4" }),
                createVNode(_component_swiper_slide, { class: "animate-pulse mx-4" }),
                createVNode(_component_swiper_slide, { class: "animate-pulse mx-4" }),
                createVNode(_component_swiper_slide, { class: "animate-pulse mx-4" }),
                createVNode(_component_swiper_slide, { class: "animate-pulse mx-4" })
              ], 64)) : (openBlock(true), createBlock(Fragment, { key: 1 }, renderList(unref(sliderData), (item) => {
                return openBlock(), createBlock(_component_swiper_slide, null, {
                  default: withCtx(() => [
                    createVNode(_component_LazyNuxtImg, {
                      format: "webp",
                      src: item.main_image,
                      quality: "50",
                      alt: item.name
                    }, null, 8, ["src", "alt"])
                  ]),
                  _: 2
                }, 1024);
              }), 256))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="swiper-button-prev md:px-4 pt-12" data-v-f9cdd237></div></div></div>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/PartnersSection.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-f9cdd237"]]);

export { __nuxt_component_1 as default };
//# sourceMappingURL=PartnersSection-b21d4271.mjs.map
