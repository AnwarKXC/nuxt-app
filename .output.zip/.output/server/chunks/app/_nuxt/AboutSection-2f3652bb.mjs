import { resolveComponent, mergeProps, withCtx, createTextVNode, toDisplayString, useSSRContext, defineAsyncComponent } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import { _ as _imports_0 } from './logo-70846ef2.mjs';
import { _ as _export_sfc } from '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';

const __nuxt_component_0_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./FetchAbout-ca63d530.mjs').then((m) => m.default || m));
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_LazyFetchAbout = __nuxt_component_0_lazy;
  const _component_RouterLink = resolveComponent("RouterLink");
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "w-screen bg-[#ECF5FB] py-10 font-arabic flex justify-center items-center" }, _attrs))}><div class="container flex flex-col md:flex-row text-center gap-10 py-5 justify-around items-center"><div class="max-w-[511px] max-h-[500px]"><h1 class="title">${ssrInterpolate(_ctx.$t("\u0645\u064A\u0646 \u0631\u064A\u0641\u0627\u064A\u0646 \u061F"))}</h1><div class="overflow-hidden line-clamp-3 h-[95px]">`);
  _push(ssrRenderComponent(_component_LazyFetchAbout, null, null, _parent));
  _push(`</div><div class="md:flex"><button class="button-prim mt-[35px]">`);
  _push(ssrRenderComponent(_component_RouterLink, { to: "/about" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`${ssrInterpolate(_ctx.$t("\u0645\u0639\u0631\u0641\u0629 \u0627\u0644\u0645\u0632\u064A\u062F"))}`);
      } else {
        return [
          createTextVNode(toDisplayString(_ctx.$t("\u0645\u0639\u0631\u0641\u0629 \u0627\u0644\u0645\u0632\u064A\u062F")), 1)
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</button></div></div><div class="max-w-[170px]"><img${ssrRenderAttr("src", _imports_0)} alt="logo"></div></div></section>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/AboutSection.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const AboutSection = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { AboutSection as default };
//# sourceMappingURL=AboutSection-2f3652bb.mjs.map
