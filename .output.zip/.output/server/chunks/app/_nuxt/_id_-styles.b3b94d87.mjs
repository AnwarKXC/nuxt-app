const _id__vue_vue_type_style_index_0_scoped_66b38b1f_lang = "p[data-v-66b38b1f]{padding:60px 0}";

const _id_Styles_b3b94d87 = [_id__vue_vue_type_style_index_0_scoped_66b38b1f_lang, _id__vue_vue_type_style_index_0_scoped_66b38b1f_lang];

export { _id_Styles_b3b94d87 as default };
//# sourceMappingURL=_id_-styles.b3b94d87.mjs.map
