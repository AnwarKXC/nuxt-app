import { useSSRContext, defineAsyncComponent } from 'vue';
import { ssrRenderList, ssrRenderComponent, ssrRenderSlot } from 'vue/server-renderer';

const __nuxt_component_0_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./ProductCard-99f306c4.mjs').then((m) => m.default || m));
const _sfc_main = {
  __name: "ProductList",
  __ssrInlineRender: true,
  props: {
    sliderData: {
      type: Array,
      default: () => []
    },
    number: {
      type: Number
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_LazyProductCard = __nuxt_component_0_lazy;
      _push(`<!--[--><section class="container font-arabic py-5"><div class="gap-[22px] relative flex justify-center items-center flex-wrap"><!--[-->`);
      ssrRenderList(__props.sliderData.slice(0, __props.number), (item) => {
        _push(ssrRenderComponent(_component_LazyProductCard, {
          key: item.id,
          item
        }, null, _parent));
      });
      _push(`<!--]--></div></section>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ProductList.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=ProductList-31c45311.mjs.map
