import __nuxt_component_0 from './FetchAbout-ca63d530.mjs';
import __nuxt_component_1 from './PartnersSection-b21d4271.mjs';
import { b as useI18n } from '../server.mjs';
import { ref, watchEffect, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _imports_0 } from './logo-70846ef2.mjs';
import axios from 'axios';
import 'swiper/vue';
import 'swiper/modules';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const { locale } = useI18n();
    let aboutData = ref([]);
    const getData = async () => {
      try {
        const response = await axios.get("https://dev.refine-care.com/api/v1/settings/page/about", {
          headers: {
            lang: locale.value
          }
        });
        const data = response.data.records.data[0];
        aboutData.value = data;
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    watchEffect(() => {
      getData();
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FetchAbout = __nuxt_component_0;
      const _component_PartnersSection = __nuxt_component_1;
      _push(`<main${ssrRenderAttrs(mergeProps({ class: "font-arabic" }, _attrs))}>`);
      if (unref(aboutData).photo) {
        _push(`<div class="text-center"><img class="w-screen aspect-[2/.84]"${ssrRenderAttr("src", unref(aboutData).photo.url)} alt=" laps"></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<section class="font-arabic flex justify-center items-center pb-10"><div class="container flex justify-around items-center text-center md:text-start gap-10 flex-col md:flex-row"><div class="max-w-[690px]"><h1 class="title">${ssrInterpolate(_ctx.$t(" \u0645\u064A\u0646 \u0631\u064A\u0641\u0627\u064A\u0646 \u061F"))}</h1>`);
      _push(ssrRenderComponent(_component_FetchAbout, null, null, _parent));
      _push(`</div><div class="md:order-first"><img width="171"${ssrRenderAttr("src", _imports_0)} alt=""></div></div></section><div class="bg-[#ECF5FB]"><section class="md:h-[314px] py-5 bg-prim text-center flex justify-center flex-col items-center"><h1 class="max-w-[960px] leading-[60px] text-2xl md:text-[48px] text-white">${ssrInterpolate(_ctx.$t(`\u0647\u0644 \u0644\u062F\u064A\u0643 \u0623\u064A \u0625\u0633\u062A\u0641\u0633\u0627\u0631 \u064A\u0633\u0639\u062F\u0646\u0627 \u062A\u0648\u0627\u0635\u0644\u0643 \u0645\u0639\u0646\u0627`))}</h1><a href=""><button class="text-[23px] text-prim bg-white px-[73px] py-2.5 rounded-[10px] my-[34px]">${ssrInterpolate(_ctx.$t("\u062A\u0648\u0627\u0635\u0644 \u0645\u0639\u0646\u0627"))}</button></a></section>`);
      _push(ssrRenderComponent(_component_PartnersSection, null, null, _parent));
      _push(`</div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/about/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-270f231b.mjs.map
