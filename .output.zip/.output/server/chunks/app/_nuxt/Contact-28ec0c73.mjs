import { ref, mergeProps, useSSRContext, defineAsyncComponent } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';

const __nuxt_component_0_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./contactDetails-ef7fe82b.mjs').then((m) => m.default || m));
const __nuxt_component_1_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./FormSection-41d96b21.mjs').then((m) => m.default || m));
const _sfc_main = {
  __name: "Contact",
  __ssrInlineRender: true,
  setup(__props) {
    ref(null);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_LazyContactDetails = __nuxt_component_0_lazy;
      const _component_LazyFormSection = __nuxt_component_1_lazy;
      _push(`<main${ssrRenderAttrs(mergeProps({ class: "container flex flex-col xl:flex-row justify-center md:gap-16 items-center font-arabic py-10 md:py-6" }, _attrs))}><div class="text-center font-arabic text-[20px] leading-[35px]"></div><div class="text-center font-arabic text-[20px] leading-[35px] -mt-4 xl:max-w-[70%]"><div class="max-w-[744px] flex justify-center items-center text-center flex-col">`);
      _push(ssrRenderComponent(_component_LazyContactDetails, null, null, _parent));
      _push(`</div></div><div><h1 class="title-contact">${ssrInterpolate(_ctx.$t("\u0643\u0646 \u0639\u0644\u064A \u062A\u0648\u0627\u0635\u0644 \u0645\u0639\u0646\u0627"))}</h1></div>`);
      _push(ssrRenderComponent(_component_LazyFormSection, null, null, _parent));
      _push(`</main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/Contact.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=Contact-28ec0c73.mjs.map
