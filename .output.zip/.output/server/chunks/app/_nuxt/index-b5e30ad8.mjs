import { withCtx, createVNode, toDisplayString, useSSRContext, defineAsyncComponent } from 'vue';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import { _ as _export_sfc } from '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';

const __nuxt_component_0_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./HeroSection-566fda53.mjs').then((m) => m.default || m));
const __nuxt_component_1_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./AboutSection-2f3652bb.mjs').then((m) => m.default || m));
const __nuxt_component_2_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./NumbersSection-5901aacf.mjs').then((m) => m.default || m));
const __nuxt_component_3_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./PartnersSection-b21d4271.mjs').then((m) => m.default || m));
const __nuxt_component_4_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./PopluarService-79079757.mjs').then((m) => m.default || m));
const __nuxt_component_5_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./BlogSection-f828cbac.mjs').then((m) => m.default || m));
const __nuxt_component_6_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./ContactUs-3f30e61a.mjs').then((m) => m.default || m));
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_LazyHeroSection = __nuxt_component_0_lazy;
  const _component_LazyAboutSection = __nuxt_component_1_lazy;
  const _component_LazyNumbersSection = __nuxt_component_2_lazy;
  const _component_LazyPartnersSection = __nuxt_component_3_lazy;
  const _component_LazyPopluarService = __nuxt_component_4_lazy;
  const _component_LazyBlogSection = __nuxt_component_5_lazy;
  const _component_LazyContactUs = __nuxt_component_6_lazy;
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_LazyHeroSection, null, null, _parent));
  _push(ssrRenderComponent(_component_LazyAboutSection, null, null, _parent));
  _push(ssrRenderComponent(_component_LazyNumbersSection, null, null, _parent));
  _push(ssrRenderComponent(_component_LazyPartnersSection, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<a href="/contact"${_scopeId}><button class="button-prim mt-10"${_scopeId}>${ssrInterpolate(_ctx.$t("\u064A\u0633\u0639\u062F\u0646\u0627 \u0627\u0646\u0636\u0645\u0627\u0645\u0643 \u0645\u0639\u0646\u0627"))}</button></a>`);
      } else {
        return [
          createVNode("a", { href: "/contact" }, [
            createVNode("button", { class: "button-prim mt-10" }, toDisplayString(_ctx.$t("\u064A\u0633\u0639\u062F\u0646\u0627 \u0627\u0646\u0636\u0645\u0627\u0645\u0643 \u0645\u0639\u0646\u0627")), 1)
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_LazyPopluarService, null, null, _parent));
  _push(ssrRenderComponent(_component_LazyBlogSection, null, null, _parent));
  _push(ssrRenderComponent(_component_LazyContactUs, null, null, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { index as default };
//# sourceMappingURL=index-b5e30ad8.mjs.map
