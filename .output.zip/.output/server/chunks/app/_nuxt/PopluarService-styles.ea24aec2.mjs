const PopluarService_vue_vue_type_style_index_0_scoped_cf6b39bd_lang = ".swiper[data-v-cf6b39bd]{width:100%}.swiper-slide[data-v-cf6b39bd]{align-items:center;background:#fff;border-radius:15px;display:flex;justify-content:center;overflow:hidden;width:150px}.swiper-slide img[data-v-cf6b39bd]{aspect-ratio:1/1;width:100%}";

const PopluarServiceStyles_ea24aec2 = [PopluarService_vue_vue_type_style_index_0_scoped_cf6b39bd_lang, PopluarService_vue_vue_type_style_index_0_scoped_cf6b39bd_lang];

export { PopluarServiceStyles_ea24aec2 as default };
//# sourceMappingURL=PopluarService-styles.ea24aec2.mjs.map
