var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var require_resizeImages_00a = __commonJS({
  "_nuxt/resizeImages-3eeef15e.js"(exports, module) {
    const sharp = require("sharp");
    const path = require("path");
    require("fs");
    module.exports = function(req, res, next) {
      const originalImagePath = path.join(__dirname, "../static", req.url);
      if (req.url.startsWith("/resize/")) {
        const width = parseInt(req.query.width) || 300;
        const height = parseInt(req.query.height) || 200;
        sharp(originalImagePath).resize(width, height).toBuffer().then((data) => {
          res.setHeader("Content-Type", "image/jpeg");
          res.end(data);
        }).catch((err) => {
          console.error(err);
          res.status(500).end("Image processing error");
        });
      } else {
        next();
      }
    };
  }
});
const resizeImages3eeef15e = require_resizeImages_00a();

export { resizeImages3eeef15e as default };
//# sourceMappingURL=resizeImages-3eeef15e.mjs.map
