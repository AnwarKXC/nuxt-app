import { Swiper, SwiperSlide } from 'swiper/vue';
import { ref, mergeProps, unref, withCtx, createVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, useSSRContext, defineAsyncComponent } from 'vue';
import { _ as _export_sfc, b as useI18n } from '../server.mjs';
import { Autoplay } from 'swiper/modules';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';

const __nuxt_component_2_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./nuxt-img-fa989413.mjs').then((m) => m.default || m));
const _sfc_main = {
  __name: "PopluarService",
  __ssrInlineRender: true,
  setup(__props) {
    useI18n();
    let sliderData = ref([]);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Swiper = Swiper;
      const _component_swiper_slide = SwiperSlide;
      const _component_LazyNuxtImg = __nuxt_component_2_lazy;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "container text-center font-arabic text-[20px] leading-[35px] flex justify-center items-center py-5 overflow-hidden" }, _attrs))} data-v-cf6b39bd><div class="max-w-[938px] container" data-v-cf6b39bd><h1 class="title" data-v-cf6b39bd>${ssrInterpolate(_ctx.$t("\u0623\u0634\u0647\u0631 \u062E\u062F\u0645\u0627\u062A\u0646\u0627"))}</h1><div class="mt-12" data-v-cf6b39bd>`);
      _push(ssrRenderComponent(_component_Swiper, {
        "slides-per-view": 6.25,
        "space-between": 25,
        loop: true,
        breakpoints: {
          "200": {
            slidesPerView: 1,
            spaceBetween: 50
          },
          "350": {
            slidesPerView: 1,
            spaceBetween: 50
          },
          "460": {
            slidesPerView: 2.5,
            spaceBetween: 40
          },
          "640": {
            slidesPerView: 3,
            spaceBetween: 20
          },
          "768": {
            slidesPerView: 3,
            spaceBetween: 40
          }
        },
        modules: ["SwiperAutoplay" in _ctx ? _ctx.SwiperAutoplay : unref(Autoplay)],
        autoplay: {
          delay: 2e3,
          disableOnInteraction: false
        },
        class: "mySwiper",
        "grab-cursor": true
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(unref(sliderData), (item) => {
              _push2(ssrRenderComponent(_component_swiper_slide, null, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<div class="text-20px flex flex-col justify-center items-center" data-v-cf6b39bd${_scopeId2}><div class="serv" data-v-cf6b39bd${_scopeId2}>`);
                    _push3(ssrRenderComponent(_component_LazyNuxtImg, {
                      format: "webp",
                      src: item.main_image,
                      alt: ""
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><p data-v-cf6b39bd${_scopeId2}>${ssrInterpolate(item.name)}</p></div>`);
                  } else {
                    return [
                      createVNode("div", { class: "text-20px flex flex-col justify-center items-center" }, [
                        createVNode("div", { class: "serv" }, [
                          createVNode(_component_LazyNuxtImg, {
                            format: "webp",
                            src: item.main_image,
                            alt: ""
                          }, null, 8, ["src"])
                        ]),
                        createVNode("p", null, toDisplayString(item.name), 1)
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(true), createBlock(Fragment, null, renderList(unref(sliderData), (item) => {
                return openBlock(), createBlock(_component_swiper_slide, null, {
                  default: withCtx(() => [
                    createVNode("div", { class: "text-20px flex flex-col justify-center items-center" }, [
                      createVNode("div", { class: "serv" }, [
                        createVNode(_component_LazyNuxtImg, {
                          format: "webp",
                          src: item.main_image,
                          alt: ""
                        }, null, 8, ["src"])
                      ]),
                      createVNode("p", null, toDisplayString(item.name), 1)
                    ])
                  ]),
                  _: 2
                }, 1024);
              }), 256))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/PopluarService.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const PopluarService = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-cf6b39bd"]]);

export { PopluarService as default };
//# sourceMappingURL=PopluarService-79079757.mjs.map
