const index_vue_vue_type_style_index_0_lang = ".pagination-container{align-items:center;display:flex;gap:10px;justify-content:center}.number-buttons{color:#000;font-weight:600}.back-button,.next-button{align-items:center;background:#146aff;border:none;border-radius:25%;color:#fff;cursor:pointer;display:flex;font-size:25px;font-weight:900;height:40px;justify-content:center;width:40px}.back-button:hover,.next-button:hover{background:#0644af}.paginate-buttons{align-items:center;border:2px solid rgba(0,0,0,.422);border-radius:25%;cursor:pointer;display:flex;height:40px;justify-content:center;width:40px}.active-page{background:#0644af;border:2px solid #0644af;color:#fff;font-weight:900}.back-btn,.next-btn{background-color:red}";

const indexStyles_e687011a = [index_vue_vue_type_style_index_0_lang, index_vue_vue_type_style_index_0_lang];

export { indexStyles_e687011a as default };
//# sourceMappingURL=index-styles.e687011a.mjs.map
