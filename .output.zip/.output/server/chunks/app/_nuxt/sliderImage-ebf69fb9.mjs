import { mergeProps, useSSRContext, defineAsyncComponent } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';

const __nuxt_component_0_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./nuxt-img-fa989413.mjs').then((m) => m.default || m));
const _sfc_main = {
  __name: "sliderImage",
  __ssrInlineRender: true,
  props: {
    item: {
      type: Object,
      default: () => ({})
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_LazyNuxtImg = __nuxt_component_0_lazy;
      _push(`<a${ssrRenderAttrs(mergeProps({
        class: "aspect-[2/.8]",
        target: "_blank",
        href: __props.item.url || "/"
      }, _attrs))} data-v-df5686d4>`);
      _push(ssrRenderComponent(_component_LazyNuxtImg, {
        format: "webp",
        quality: "50",
        class: "w-screen aspect-[2/.88]",
        src: __props.item.main_image,
        alt: __props.item.description || "slide"
      }, null, _parent));
      _push(`</a>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/sliderImage.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const sliderImage = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-df5686d4"]]);

export { sliderImage as default };
//# sourceMappingURL=sliderImage-ebf69fb9.mjs.map
