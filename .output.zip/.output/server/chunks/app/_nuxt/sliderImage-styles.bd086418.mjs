const sliderImage_vue_vue_type_style_index_0_scoped_df5686d4_lang = ".flip-img[data-v-df5686d4]{transform:rotateY(180deg)}";

const sliderImageStyles_bd086418 = [sliderImage_vue_vue_type_style_index_0_scoped_df5686d4_lang, sliderImage_vue_vue_type_style_index_0_scoped_df5686d4_lang];

export { sliderImageStyles_bd086418 as default };
//# sourceMappingURL=sliderImage-styles.bd086418.mjs.map
