import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { ref, watch, unref, withCtx, createVNode, toDisplayString, useSSRContext, defineAsyncComponent } from 'vue';
import { _ as _export_sfc, b as useI18n, d as useRoute, a as __nuxt_component_0$2 } from '../server.mjs';
import { ssrInterpolate, ssrRenderAttr, ssrRenderList, ssrRenderComponent } from 'vue/server-renderer';
import axios from 'axios';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';

const _imports_0 = "" + buildAssetsURL("faceimg.9f57cee5.svg");
const _imports_1 = "" + buildAssetsURL("instaimg.c10bbf1b.svg");
const _imports_2 = "" + buildAssetsURL("whatsimg.7a0e75f6.svg");
const _imports_3 = "" + buildAssetsURL("twitterimg.585fdad1.svg");
const _imports_4 = "" + buildAssetsURL("linkdimg.e4c31654.svg");
const __nuxt_component_0_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./LastArticle-e838a7cc.mjs').then((m) => m.default || m));
const _sfc_main = {
  __name: "[id]",
  __ssrInlineRender: true,
  setup(__props) {
    const { locale } = useI18n();
    const route = useRoute();
    let mainArticle = ref({});
    let allArticles = ref([]);
    let filterdArr = ref([]);
    let id = ref(route.params.id);
    ref("");
    const fetchMainArticle = async (articleId) => {
      try {
        const response = await axios.get(`https://dev.refine-care.com/api/v1/blog/${articleId}`, {
          headers: {
            lang: locale.value
          }
        });
        const data1 = response.data.record;
        mainArticle.value = data1;
      } catch (error) {
        console.error("Error fetching main article:", error);
      }
    };
    const fetchAllArticles = async () => {
      try {
        const response = await axios.get("https://dev.refine-care.com/api/v1/blogs?page=" + id, {
          headers: {
            lang: locale.value
          }
        });
        let data = response.data.records;
        let filterdData = data.data.filter((item) => item.id != id.value);
        allArticles.value = data;
        filterdArr.value = filterdData;
      } catch (error) {
        console.error("Error fetching all articles:", error);
      }
    };
    ref(null);
    watch((locale.value, async (newlocal, oldlocal) => {
      await fetchMainArticle(id.value);
      await fetchAllArticles();
    }));
    watch(route, async (newRoute) => {
      let newId = newRoute.params.id;
      fetchMainArticle(newId);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_LazyLastArticle = __nuxt_component_0_lazy;
      const _component_NuxtLink = __nuxt_component_0$2;
      _push(`<!--[--><main class="container font-arabic pt-7" data-v-66b38b1f><section class="md:flex gap-5" data-v-66b38b1f><div class="md:w-[2/3]" data-v-66b38b1f><h4 class="text-sm font-bold" data-v-66b38b1f>${ssrInterpolate(unref(mainArticle).created_at)}</h4><h2 class="text-3xl py-5 font-bold" data-v-66b38b1f>${ssrInterpolate(unref(mainArticle).title)}</h2><div class="relative" data-v-66b38b1f><div class="min-w-[320px] aspect-[2/1] rounded-[15px] overflow-hidden relative" data-v-66b38b1f><img class="w-full absolute inset-0 aspect-[2/1]"${ssrRenderAttr("src", unref(mainArticle).main_image)} alt="article photo" data-v-66b38b1f><div class="flex gap-6 absolute bottom-0 px-6 py-8 bg-gradient-to-t from-black to-[#00000000] w-full" data-v-66b38b1f><span class="text-white cursor-pointer hover:text-prim" data-v-66b38b1f>${ssrInterpolate(_ctx.$t("\u0634\u0627\u0631\u0643"))}</span><div class="flex gap-1" data-v-66b38b1f><a href="" data-v-66b38b1f><img width="24"${ssrRenderAttr("src", _imports_0)} alt="" data-v-66b38b1f></a><a href="" data-v-66b38b1f><img width="24"${ssrRenderAttr("src", _imports_1)} alt="" data-v-66b38b1f></a><a href="" data-v-66b38b1f><img width="24"${ssrRenderAttr("src", _imports_2)} alt="" data-v-66b38b1f></a><a href="" data-v-66b38b1f><img width="24"${ssrRenderAttr("src", _imports_3)} alt="" data-v-66b38b1f></a><a href="" data-v-66b38b1f><img width="24"${ssrRenderAttr("src", _imports_4)} alt="" data-v-66b38b1f></a></div></div></div><h5 class="text-[19px] leading-[50px]" data-v-66b38b1f>${unref(mainArticle).description}</h5></div></div><div class="py-24 md:w-[1/3] md:block flex justify-center flex-col items-center" data-v-66b38b1f><h2 class="text-2xl" data-v-66b38b1f>${ssrInterpolate(_ctx.$t("\u0622\u062E\u0631 \u0627\u0644\u0645\u0642\u0627\u0644\u0627\u062A"))}</h2><!--[-->`);
      ssrRenderList(unref(filterdArr).slice(0, 2), (item) => {
        _push(`<div class="flex flex-col gap-6 flex-grow md:flex-grow-0" data-v-66b38b1f>`);
        _push(ssrRenderComponent(_component_LazyLastArticle, {
          item,
          key: item.id
        }, null, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--><div class="flex justify-end flex-col md:flex-row" data-v-66b38b1f><a href="/blog" data-v-66b38b1f><button class="button-prim text-xl mt-6" data-v-66b38b1f>${ssrInterpolate(_ctx.$t("\u0627\u0644\u0645\u0632\u064A\u062F"))}<span class="font-bold" data-v-66b38b1f>+</span></button></a></div></div></section><section data-v-66b38b1f><div class="mt-16 flex justify-center items-center gap-8 flex-col md:flex-row" data-v-66b38b1f><div class="flex flex-col gap-4 flex-grow" data-v-66b38b1f><h2 class="text-[21px] font-bold" data-v-66b38b1f>${ssrInterpolate(_ctx.$t("\u0645\u0642\u0627\u0644\u0627\u062A \u0645\u0642\u062A\u0631\u062D\u0629"))}</h2><!--[-->`);
      ssrRenderList(unref(filterdArr).slice(2, 6), (item, index) => {
        _push(`<div data-v-66b38b1f>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/blog/${item.id}/?${item.title.split(" ").join("-")}`,
          key: item.id
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="cursor-pointer relative flex justify-start items-center gap-4 border border-[#BFBFBF] py-5 px-2 rounded-[15px] font-bold" data-v-66b38b1f${_scopeId}><span class="w-10 h-10 flex justify-center items-center rounded-full border-2 pl-1 font-bold border-prim" data-v-66b38b1f${_scopeId}><span class="mr-1.5" data-v-66b38b1f${_scopeId}>${ssrInterpolate(index + 1)}</span></span><h2 data-v-66b38b1f${_scopeId}>${ssrInterpolate(item.title)}</h2></div>`);
            } else {
              return [
                createVNode("div", { class: "cursor-pointer relative flex justify-start items-center gap-4 border border-[#BFBFBF] py-5 px-2 rounded-[15px] font-bold" }, [
                  createVNode("span", { class: "w-10 h-10 flex justify-center items-center rounded-full border-2 pl-1 font-bold border-prim" }, [
                    createVNode("span", { class: "mr-1.5" }, toDisplayString(index + 1), 1)
                  ]),
                  createVNode("h2", null, toDisplayString(item.title), 1)
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--></div><div class="flex flex-col gap-4 flex-grow" data-v-66b38b1f><h2 class="text-[21px] font-bold" data-v-66b38b1f>${ssrInterpolate(_ctx.$t("\u0627\u0644\u0623\u0643\u062B\u0631 \u0642\u0631\u0627\u0621\u0629"))}</h2><!--[-->`);
      ssrRenderList(unref(filterdArr).slice(0, 3), (item, index) => {
        _push(`<div data-v-66b38b1f>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/blog/${item.id}/?${item.title.split(" ").join("-")}`,
          key: item.id
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="cursor-pointer relative flex justify-start items-center gap-4 border border-[#BFBFBF] py-5 px-2 rounded-[15px] font-bold" data-v-66b38b1f${_scopeId}><span class="w-10 h-10 flex justify-center items-center rounded-full border-2 pl-1 font-bold border-prim" data-v-66b38b1f${_scopeId}><span class="mr-1.5" data-v-66b38b1f${_scopeId}>${ssrInterpolate(index + 1)}</span></span><h2 data-v-66b38b1f${_scopeId}>${ssrInterpolate(item.title)}</h2></div>`);
            } else {
              return [
                createVNode("div", { class: "cursor-pointer relative flex justify-start items-center gap-4 border border-[#BFBFBF] py-5 px-2 rounded-[15px] font-bold" }, [
                  createVNode("span", { class: "w-10 h-10 flex justify-center items-center rounded-full border-2 pl-1 font-bold border-prim" }, [
                    createVNode("span", { class: "mr-1.5" }, toDisplayString(index + 1), 1)
                  ]),
                  createVNode("h2", null, toDisplayString(item.title), 1)
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--></div></div></section></main><h2 data-v-66b38b1f></h2><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/blog/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _id_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-66b38b1f"]]);

export { _id_ as default };
//# sourceMappingURL=_id_-df11b341.mjs.map
