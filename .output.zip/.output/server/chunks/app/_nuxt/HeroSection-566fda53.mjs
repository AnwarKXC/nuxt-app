import { ref, watchEffect, mergeProps, unref, withCtx, openBlock, createBlock, Fragment, createVNode, renderList, useSSRContext, defineAsyncComponent } from 'vue';
import { Swiper, SwiperSlide } from 'swiper/vue';
import { _ as _export_sfc, b as useI18n } from '../server.mjs';
import { Pagination, Autoplay } from 'swiper/modules';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import axios from 'axios';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';

const __nuxt_component_0_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./SwippingTop-04c0e3cb.mjs').then((m) => m.default || m));
const __nuxt_component_3_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./sliderImage-ebf69fb9.mjs').then((m) => m.default || m));
const _sfc_main = {
  __name: "HeroSection",
  __ssrInlineRender: true,
  setup(__props) {
    const { locale } = useI18n();
    let isLoading = ref(true);
    let sliderData = ref([]);
    const getData = async () => {
      try {
        const response = await axios.get("https://dev.refine-care.com/api/v1/slider", {
          headers: {
            lang: locale.value
          }
        });
        const data = response.data.records;
        sliderData.value = data;
        isLoading.value = false;
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    const value = ref(false);
    ref(null);
    watchEffect(() => {
      getData();
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_LazySwippingTop = __nuxt_component_0_lazy;
      const _component_swiper = Swiper;
      const _component_swiper_slide = SwiperSlide;
      const _component_LazySliderImage = __nuxt_component_3_lazy;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "relative" }, _attrs))} data-v-ee304732><div class="z-10 fixed hidden md:flex flex-col bottom-10 rtl:right-2 ltr:left-2" data-v-ee304732>`);
      _push(ssrRenderComponent(_component_LazySwippingTop, null, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_swiper, {
        class: "mySwiper",
        "slides-per-view": 1,
        loop: true,
        autoplay: {
          delay: 3e3,
          disableOnInteraction: false
        },
        "grab-cursor": true,
        modules: ["SwiperPagination" in _ctx ? _ctx.SwiperPagination : unref(Pagination), "SwiperAutoplay" in _ctx ? _ctx.SwiperAutoplay : unref(Autoplay)],
        pagination: unref(value)
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (unref(isLoading)) {
              _push2(`<!--[-->`);
              _push2(ssrRenderComponent(_component_swiper_slide, { class: "animate-pulse" }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_swiper_slide, { class: "animate-pulse" }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_swiper_slide, { class: "animate-pulse" }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_swiper_slide, { class: "animate-pulse" }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_swiper_slide, { class: "animate-pulse" }, null, _parent2, _scopeId));
              _push2(`<!--]-->`);
            } else {
              _push2(`<!--[-->`);
              ssrRenderList(unref(sliderData), (item) => {
                _push2(ssrRenderComponent(_component_swiper_slide, null, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(_component_LazySliderImage, {
                        item,
                        key: item.id
                      }, null, _parent3, _scopeId2));
                    } else {
                      return [
                        (openBlock(), createBlock(_component_LazySliderImage, {
                          item,
                          key: item.id
                        }, null, 8, ["item"]))
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]-->`);
            }
          } else {
            return [
              unref(isLoading) ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                createVNode(_component_swiper_slide, { class: "animate-pulse" }),
                createVNode(_component_swiper_slide, { class: "animate-pulse" }),
                createVNode(_component_swiper_slide, { class: "animate-pulse" }),
                createVNode(_component_swiper_slide, { class: "animate-pulse" }),
                createVNode(_component_swiper_slide, { class: "animate-pulse" })
              ], 64)) : (openBlock(true), createBlock(Fragment, { key: 1 }, renderList(unref(sliderData), (item) => {
                return openBlock(), createBlock(_component_swiper_slide, null, {
                  default: withCtx(() => [
                    (openBlock(), createBlock(_component_LazySliderImage, {
                      item,
                      key: item.id
                    }, null, 8, ["item"]))
                  ]),
                  _: 2
                }, 1024);
              }), 256))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/HeroSection.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const HeroSection = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-ee304732"]]);

export { HeroSection as default };
//# sourceMappingURL=HeroSection-566fda53.mjs.map
