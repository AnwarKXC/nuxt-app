import { ref, watchEffect, mergeProps, unref, useSSRContext } from 'vue';
import { b as useI18n } from '../server.mjs';
import { ssrRenderAttrs, ssrInterpolate } from 'vue/server-renderer';
import axios from 'axios';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';

const _sfc_main = {
  __name: "Terms",
  __ssrInlineRender: true,
  setup(__props) {
    ref(null);
    const { locale } = useI18n();
    let termsOf = ref([]);
    const getData = async () => {
      try {
        const response = await axios.get("https://dev.refine-care.com/api/v1/settings/page/terms_and_conditions", {
          headers: {
            lang: locale.value
          }
        });
        const data = response.data.records.data[0];
        termsOf.value = data;
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    watchEffect(() => {
      getData();
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container min-h-screen font-arabic" }, _attrs))}><h1 class="title">${ssrInterpolate(_ctx.$t("\u0634\u0631\u0648\u0637 \u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645"))}</h1><p class="leading-8">${unref(termsOf).page}</p></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/Terms.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=Terms-3f2f5727.mjs.map
