import { h as __nuxt_component_0 } from '../server.mjs';
import { ref, unref, useSSRContext } from 'vue';
import { ssrRenderAttr, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _imports_3, a as _imports_4 } from './up-d5a59b14.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main = {
  __name: "SwippingTop",
  __ssrInlineRender: true,
  setup(__props) {
    let isOpen = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_socialMedia = __nuxt_component_0;
      _push(`<!--[--><div><div class="relative"><img class="cursor-pointer" width="80"${ssrRenderAttr("src", _imports_3)} alt="options">`);
      if (unref(isOpen)) {
        _push(`<div class="-z-10 absolute bottom-[2.5rem] rounded-t-full py-16 pt-4 right-[7.5px] w-[65px] gap-4 bg-prim"><div class="absolute -top-2.5 scale-125"><img${ssrRenderAttr("src", _imports_3)} alt="options"></div><div class="scale-125 invert flex justify-center flex-col gap-4 items-center pt-14">`);
        _push(ssrRenderComponent(_component_socialMedia, null, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="cursor-pointer w-[105] flex justify-center"><img width="28"${ssrRenderAttr("src", _imports_4)} alt="options"></div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/SwippingTop.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=SwippingTop-04c0e3cb.mjs.map
