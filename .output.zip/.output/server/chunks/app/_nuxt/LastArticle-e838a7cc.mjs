import { a as __nuxt_component_0$2 } from '../server.mjs';
import __nuxt_component_1 from './nuxt-img-fa989413.mjs';
import { mergeProps, withCtx, createVNode, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';

const _sfc_main = {
  __name: "LastArticle",
  __ssrInlineRender: true,
  props: {
    item: {
      type: Object,
      default: () => ({})
      // Default value for the image prop
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$2;
      const _component_NuxtImg = __nuxt_component_1;
      _push(ssrRenderComponent(_component_NuxtLink, mergeProps({
        class: "flex-grow",
        to: `/blog/${__props.item.id}/?${__props.item.title.split(" ").join("-")}`
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="cursor-pointer flex gap-1 rounded-[15px] overflow-hidden border border-[#BFBFBF] max-w-[350px] min-w-[250px] md:max-w-[260px] lg:min-w-[300px] xl:min-w-[400px] aspect-[4/1] my-2"${_scopeId}><div class="aspect-[2/1] h-full"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_NuxtImg, {
              format: "webp",
              class: "aspect-[2/1]",
              src: __props.item.main_image,
              alt: " article photo"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}><h2 class="font-semibold pt-1 pr-1 lg:text-[15px] md:mb-1 md:leading-4 leading-5 line-clamp-2 md:text-xs xl:h-[36px] overflow-hidden"${_scopeId}>${ssrInterpolate(__props.item.title)}</h2><p class="md:line-clamp-2 md:h-[30px] lg:h-[49px] line-clamp-3 lg:line-clamp-3 md:leading-2 xl:text-xs text-[11px] h-[48px] overflow-hidden text-zinc-700 pr-1"${_scopeId}>${__props.item.description}</p></div></div>`);
          } else {
            return [
              createVNode("div", { class: "cursor-pointer flex gap-1 rounded-[15px] overflow-hidden border border-[#BFBFBF] max-w-[350px] min-w-[250px] md:max-w-[260px] lg:min-w-[300px] xl:min-w-[400px] aspect-[4/1] my-2" }, [
                createVNode("div", { class: "aspect-[2/1] h-full" }, [
                  createVNode(_component_NuxtImg, {
                    format: "webp",
                    class: "aspect-[2/1]",
                    src: __props.item.main_image,
                    alt: " article photo"
                  }, null, 8, ["src"])
                ]),
                createVNode("div", null, [
                  createVNode("h2", { class: "font-semibold pt-1 pr-1 lg:text-[15px] md:mb-1 md:leading-4 leading-5 line-clamp-2 md:text-xs xl:h-[36px] overflow-hidden" }, toDisplayString(__props.item.title), 1),
                  createVNode("p", {
                    innerHTML: __props.item.description,
                    class: "md:line-clamp-2 md:h-[30px] lg:h-[49px] line-clamp-3 lg:line-clamp-3 md:leading-2 xl:text-xs text-[11px] h-[48px] overflow-hidden text-zinc-700 pr-1"
                  }, null, 8, ["innerHTML"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/LastArticle.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=LastArticle-e838a7cc.mjs.map
