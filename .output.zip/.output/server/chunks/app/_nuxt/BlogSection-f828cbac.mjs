import { b as useI18n, a as __nuxt_component_0$2 } from '../server.mjs';
import { ref, watchEffect, mergeProps, withCtx, createVNode, createTextVNode, toDisplayString, unref, useSSRContext, defineAsyncComponent } from 'vue';
import { _ as __nuxt_component_2 } from './ProductCardSkelton-1ccd90d3.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import axios from 'axios';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';

const __nuxt_component_1_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./ProductList-31c45311.mjs').then((m) => m.default || m));
const _sfc_main = {
  __name: "BlogSection",
  __ssrInlineRender: true,
  setup(__props) {
    const sliderData = ref([]);
    const { locale } = useI18n();
    const getData = async (page) => {
      try {
        const response = await axios.get(`https://dev.refine-care.com/api/v1/blogs?page=${page}`, {
          headers: {
            lang: locale.value
          }
        });
        const data = response.data.records.data;
        sliderData.value = data;
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    watchEffect(() => {
      getData(1);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$2;
      const _component_LazyProductList = __nuxt_component_1_lazy;
      const _component_ProductCardSkelton = __nuxt_component_2;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "w-screen bg-[#FAFAFB] flex justify-center items-center font-arabic pb-10" }, _attrs))}><div class="container"><div class="max-w-[1175px] mx-auto"><div class="flex md:justify-between items-center justify-center"><h1 class="title">${ssrInterpolate(_ctx.$t("\u0627\u0644\u0645\u062F\u0648\u0646\u0629"))}</h1>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        "aria-label": "Show more",
        to: "/blog"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button class="button-prim hidden md:inline-flex"${_scopeId}>${ssrInterpolate(_ctx.$t("\u0627\u0644\u0645\u0632\u064A\u062F"))} <span class="font-bold"${_scopeId}>+</span></button>`);
          } else {
            return [
              createVNode("button", { class: "button-prim hidden md:inline-flex" }, [
                createTextVNode(toDisplayString(_ctx.$t("\u0627\u0644\u0645\u0632\u064A\u062F")) + " ", 1),
                createVNode("span", { class: "font-bold" }, "+")
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex justify-center flex-wrap items-center gap-[22px] text-center pt-8">`);
      if (unref(sliderData)[0]) {
        _push(ssrRenderComponent(_component_LazyProductList, {
          number: 3,
          sliderData: unref(sliderData)
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (!unref(sliderData)[0]) {
        _push(ssrRenderComponent(_component_ProductCardSkelton, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/BlogSection.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=BlogSection-f828cbac.mjs.map
