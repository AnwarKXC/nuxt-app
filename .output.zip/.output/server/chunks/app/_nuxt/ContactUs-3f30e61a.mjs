import { mergeProps, useSSRContext, defineAsyncComponent } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';

const __nuxt_component_0_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./contactDetails-ef7fe82b.mjs').then((m) => m.default || m));
const __nuxt_component_1_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./FormSection-41d96b21.mjs').then((m) => m.default || m));
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_LazyContactDetails = __nuxt_component_0_lazy;
  const _component_LazyFormSection = __nuxt_component_1_lazy;
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "w-screen bg-[#ECF5FB] flex justify-center items-center font-arabic flex-col py-4" }, _attrs))}><div class="max-w-[744px] text-center font-arabic text-[18px] leading-[35px]"><div class="text-start"><h1 class="title-contact text-center">${ssrInterpolate(_ctx.$t("\u062A\u0648\u0627\u0635\u0644 \u0645\u0639\u0646\u0627"))}</h1><div class="flex flex-col md:flex-row justify-between gap-16 items-center mt-[25px]">`);
  _push(ssrRenderComponent(_component_LazyContactDetails, null, null, _parent));
  _push(`</div></div></div>`);
  _push(ssrRenderComponent(_component_LazyFormSection, null, null, _parent));
  _push(`</section>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ContactUs.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const ContactUs = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { ContactUs as default };
//# sourceMappingURL=ContactUs-3f30e61a.mjs.map
