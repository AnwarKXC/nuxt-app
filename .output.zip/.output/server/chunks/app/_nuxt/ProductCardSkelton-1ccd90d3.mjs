import { useSSRContext, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from '../server.mjs';

const _sfc_main$1 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "animate-pulse bg-gradient-to-r from-gray-300" }, _attrs))}> \xA0 </div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/AnimatedPlaceholder.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_AnimatedPlaceholder = __nuxt_component_0;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col overflow-hidden w-[370px] tracking-wide" }, _attrs))}><div class="bg-[url(&#39;../assets/logo.png&#39;)] border border-[#BFBFBF] rounded-t-[15px] overflow-hidden bg-contain animate-pulse aspect-[2/.8] bg-center bg-no-repeat w-full"></div><div class="h-[150px] text-start p-2 border border-[#BFBFBF] border-t-0 rounded-b-[15px] overflow-hidden text-ellipsis flex flex-col gap-2">`);
  _push(ssrRenderComponent(_component_AnimatedPlaceholder, { class: "text-[20px] pb-2 mb-2" }, null, _parent));
  _push(ssrRenderComponent(_component_AnimatedPlaceholder, { class: "-mt-1" }, null, _parent));
  _push(ssrRenderComponent(_component_AnimatedPlaceholder, { class: "-mt-1" }, null, _parent));
  _push(ssrRenderComponent(_component_AnimatedPlaceholder, { class: "-mt-1" }, null, _parent));
  _push(`</div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ProductCardSkelton.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { __nuxt_component_2 as _ };
//# sourceMappingURL=ProductCardSkelton-1ccd90d3.mjs.map
