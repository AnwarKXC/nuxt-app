import { a as __nuxt_component_0$2 } from '../server.mjs';
import { mergeProps, withCtx, createVNode, openBlock, createBlock, createCommentVNode, toDisplayString, useSSRContext, defineAsyncComponent } from 'vue';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';

const __nuxt_component_1_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./nuxt-img-fa989413.mjs').then((m) => m.default || m));
const _sfc_main = {
  __name: "ProductCard",
  __ssrInlineRender: true,
  props: {
    item: {
      type: Object,
      default: () => ({})
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$2;
      const _component_LazyNuxtImg = __nuxt_component_1_lazy;
      _push(ssrRenderComponent(_component_NuxtLink, mergeProps({
        to: `/blog/${__props.item.id}/?${__props.item.title.split(" ").join("-")}`
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-col overflow-hidden max-w-[370px] tracking-wide"${_scopeId}><div class="border border-[#BFBFBF] rounded-t-[15px] overflow-hidden"${_scopeId}>`);
            if (__props.item.main_image) {
              _push2(ssrRenderComponent(_component_LazyNuxtImg, {
                loading: "lazy",
                format: "webp",
                class: "aspect-[2/.8] w-full",
                src: __props.item.main_image,
                alt: "slider"
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="h-[150px] text-start p-2 border border-[#BFBFBF] border-t-0 rounded-b-[15px] inline"${_scopeId}><div class="pb-3 text-[18px] font-bold inline"${_scopeId}>${ssrInterpolate(__props.item.title)}</div><p class="h-[95px] overflow-hidden line-clamp-4 leading-6 text-sm tracking-wide text-zinc-700"${_scopeId}>${__props.item.description}</p></div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col overflow-hidden max-w-[370px] tracking-wide" }, [
                createVNode("div", { class: "border border-[#BFBFBF] rounded-t-[15px] overflow-hidden" }, [
                  __props.item.main_image ? (openBlock(), createBlock(_component_LazyNuxtImg, {
                    key: 0,
                    loading: "lazy",
                    format: "webp",
                    class: "aspect-[2/.8] w-full",
                    src: __props.item.main_image,
                    alt: "slider"
                  }, null, 8, ["src"])) : createCommentVNode("", true)
                ]),
                createVNode("div", { class: "h-[150px] text-start p-2 border border-[#BFBFBF] border-t-0 rounded-b-[15px] inline" }, [
                  createVNode("div", { class: "pb-3 text-[18px] font-bold inline" }, toDisplayString(__props.item.title), 1),
                  createVNode("p", {
                    innerHTML: __props.item.description,
                    class: "h-[95px] overflow-hidden line-clamp-4 leading-6 text-sm tracking-wide text-zinc-700"
                  }, null, 8, ["innerHTML"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ProductCard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=ProductCard-99f306c4.mjs.map
