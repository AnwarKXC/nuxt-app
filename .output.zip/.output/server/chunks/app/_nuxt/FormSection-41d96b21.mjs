import { ref, mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';

const _sfc_main = {
  __name: "FormSection",
  __ssrInlineRender: true,
  setup(__props) {
    ref("");
    ref("");
    ref("");
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<form${ssrRenderAttrs(mergeProps({ class: "text-start md:pt-6 container max-w-[744px]" }, _attrs))}><div class="flex flex-col md:flex-row justify-center items-center md:gap-10"><div class="flex flex-col container"><label for="form">${ssrInterpolate(_ctx.$t("\u0627\u0644\u0625\u0633\u0645"))}</label><input autocomplete="additional-name" id="form" maxlength="100" minlength="10" type="name"${ssrRenderAttr("placeholder", _ctx.$t("\u0642\u0645 \u0628\u0625\u062F\u062E\u0627\u0644 \u0627\u0644\u0627\u0633\u0645"))}></div><div class="flex flex-col container md:w-full"><label for="email">${ssrInterpolate(_ctx.$t("\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0627\u0644\u0643\u062A\u0631\u0648\u0646\u064A"))}</label><input autocomplete="additional-name" type="email" name="email" id="email"${ssrRenderAttr("placeholder", _ctx.$t("\u0642\u0645 \u0628\u0625\u062F\u062E\u0627\u0644 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0627\u0644\u0643\u062A\u0631\u0648\u0646\u064A"))}></div></div><div class="flex flex-col px-2 md:px-0"><label for="message">${ssrInterpolate(_ctx.$t("\u0627\u0644\u0631\u0633\u0627\u0644\u0629"))}</label><textarea id="message"${ssrRenderAttr("placeholder", _ctx.$t("... \u064A\u0633\u0639\u062F\u0646\u0627 \u0642\u0631\u0627\u0621\u0629 \u0631\u0633\u0627\u0644\u062A\u0643"))} rows="4"></textarea></div><div class="flex justify-center"><button type="submit" class="button-prim mt-10">${ssrInterpolate(_ctx.$t("\u064A\u0633\u0639\u062F\u0646\u0627 \u0627\u0646\u0636\u0645\u0627\u0645\u0643 \u0645\u0639\u0646\u0627"))}</button></div></form>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/FormSection.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=FormSection-41d96b21.mjs.map
